import tweepy
from django.conf import settings

class TwitterAPI:
    def __init__(self, access_token, access_token_secret):
        auth = tweepy.OAuth1UserHandler(
            settings.TWITTER_API_KEY,
            settings.TWITTER_API_SECRET,
            access_token,
            access_token_secret
        )
        self.api = tweepy.API(auth)
    
    def get_user_timeline(self, count=20):
        try:
            return self.api.home_timeline(count=count)
        except Exception as e:
            print(f"Error fetching Twitter timeline: {e}")
            return []
    
    def post_tweet(self, content, image=None):
        try:
            if image:
                return self.api.update_status_with_media(content, image)
            else:
                return self.api.update_status(content)
        except Exception as e:
            print(f"Error posting tweet: {e}")
            return None
    
    def like_tweet(self, tweet_id):
        try:
            return self.api.create_favorite(tweet_id)
        except Exception as e:
            print(f"Error liking tweet: {e}")
            return None