import facebook
from django.conf import settings

class FacebookAPI:
    def __init__(self, access_token):
        self.graph = facebook.GraphAPI(access_token)
    
    def get_user_posts(self, limit=20):
        try:
            return self.graph.get_connections("me", "posts", limit=limit)
        except Exception as e:
            print(f"Error fetching Facebook posts: {e}")
            return []
    
    def post_to_facebook(self, content, image=None):
        try:
            if image:
                return self.graph.put_photo(image=open(image, 'rb'), message=content)
            else:
                return self.graph.put_object("me", "feed", message=content)
        except Exception as e:
            print(f"Error posting to Facebook: {e}")
            return None
    
    def like_post(self, post_id):
        try:
            return self.graph.put_like(object_id=post_id)
        except Exception as e:
            print(f"Error liking Facebook post: {e}")
            return None