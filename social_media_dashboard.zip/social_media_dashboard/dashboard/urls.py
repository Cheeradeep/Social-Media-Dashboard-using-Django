# dashboard/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard_home, name='dashboard_home'),
    path('profile/', views.profile, name='profile'),
    path('create-post/', views.create_post, name='create_post'),
    path('connect/twitter/', views.connect_twitter, name='connect_twitter'),
    path('connect/facebook/', views.connect_facebook, name='connect_facebook'),
    path('like/<str:platform>/<str:post_id>/', views.like_post, name='like_post'),
    path('comment/<str:platform>/<str:post_id>/', views.comment_post, name='comment_post'),
]