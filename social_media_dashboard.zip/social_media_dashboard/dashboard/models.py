# dashboard/models.py
from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(blank=True)
    profile_picture = models.ImageField(upload_to='profile_pics', blank=True)
    
    def __str__(self):
        return f"{self.user.username}'s profile"

class SocialAccount(models.Model):
    PLATFORM_CHOICES = [
        ('twitter', 'Twitter'),
        ('facebook', 'Facebook'),
        ('instagram', 'Instagram'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    platform = models.CharField(max_length=20, choices=PLATFORM_CHOICES)
    access_token = models.CharField(max_length=255)
    access_token_secret = models.CharField(max_length=255, blank=True)  # For Twitter
    account_id = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    
    class Meta:
        unique_together = ('user', 'platform')
    
    def __str__(self):
        return f"{self.user.username}'s {self.platform} account"

class Post(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    social_account = models.ForeignKey(SocialAccount, on_delete=models.CASCADE)
    platform_post_id = models.CharField(max_length=100)
    content = models.TextField()
    created_at = models.DateTimeField()
    likes_count = models.IntegerField(default=0)
    comments_count = models.IntegerField(default=0)
    shares_count = models.IntegerField(default=0)
    
    def __str__(self):
        return f"Post by {self.user.username} on {self.social_account.platform}"

class ScheduledPost(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    image = models.ImageField(upload_to='scheduled_posts', blank=True)
    scheduled_time = models.DateTimeField()
    platforms = models.ManyToManyField(SocialAccount)
    is_posted = models.BooleanField(default=False)
    
    def __str__(self):
        return f"Scheduled post by {self.user.username} at {self.scheduled_time}"