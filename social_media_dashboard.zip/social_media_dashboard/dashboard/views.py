from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import UserProfile, SocialAccount, Post, ScheduledPost
from .forms import UserProfileForm, ScheduledPostForm
from social_integrations.twitter import TwitterAPI
from social_integrations.facebook import FacebookAPI
import datetime

@login_required
def dashboard_home(request):
    social_accounts = SocialAccount.objects.filter(user=request.user)
    posts = []
    
    for account in social_accounts:
        if account.platform == 'twitter':
            api = TwitterAPI(account.access_token, account.access_token_secret)
            tweets = api.get_user_timeline()
            for tweet in tweets:
                posts.append({
                    'platform': 'twitter',
                    'content': tweet.text,
                    'created_at': tweet.created_at,
                    'likes': tweet.favorite_count,
                    'retweets': tweet.retweet_count,
                    'id': tweet.id
                })
        elif account.platform == 'facebook':
            api = FacebookAPI(account.access_token)
            fb_posts = api.get_user_posts()
            for post in fb_posts['data']:
                posts.append({
                    'platform': 'facebook',
                    'content': post.get('message', ''),
                    'created_at': datetime.datetime.strptime(post['created_time'], '%Y-%m-%dT%H:%M:%S+0000'),
                    'likes': post.get('likes', {}).get('summary', {}).get('total_count', 0),
                    'id': post['id']
                })
    
    # Sort posts by creation date
    posts.sort(key=lambda x: x['created_at'], reverse=True)
    
    scheduled_posts = ScheduledPost.objects.filter(user=request.user, is_posted=False)
    
    return render(request, 'dashboard/home.html', {
        'posts': posts,
        'scheduled_posts': scheduled_posts
    })

@login_required
def profile(request):
    try:
        profile = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        profile = UserProfile(user=request.user)
        profile.save()
    
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')
    else:
        form = UserProfileForm(instance=profile)
    
    social_accounts = SocialAccount.objects.filter(user=request.user)
    
    return render(request, 'dashboard/profile.html', {
        'form': form,
        'social_accounts': social_accounts
    })

@login_required
def create_post(request):
    if request.method == 'POST':
        content = request.POST.get('content')
        platforms = request.POST.getlist('platforms')
        schedule = request.POST.get('schedule')
        
        if schedule:
            form = ScheduledPostForm(request.POST, request.FILES)
            if form.is_valid():
                scheduled_post = form.save(commit=False)
                scheduled_post.user = request.user
                scheduled_post.save()
                
                # Add selected platforms
                for platform_id in platforms:
                    account = SocialAccount.objects.get(id=platform_id)
                    scheduled_post.platforms.add(account)
                
                messages.success(request, 'Post scheduled successfully!')
                return redirect('dashboard_home')
        else:
            # Post immediately
            image = None
            if 'image' in request.FILES:
                image = request.FILES['image']
            
            for platform_id in platforms:
                account = SocialAccount.objects.get(id=platform_id)
                
                if account.platform == 'twitter':
                    api = TwitterAPI(account.access_token, account.access_token_secret)
                    api.post_tweet(content, image)
                
                elif account.platform == 'facebook':
                    api = FacebookAPI(account.access_token)
                    api.post_to_facebook(content, image)
            
            messages.success(request, 'Post shared successfully!')
            return redirect('dashboard_home')
    
    social_accounts = SocialAccount.objects.filter(user=request.user)
    form = ScheduledPostForm()
    
    return render(request, 'dashboard/create_post.html', {
        'social_accounts': social_accounts,
        'form': form
    })